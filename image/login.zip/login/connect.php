<?php
// $uploadPhoto=$_POST['upload'];
// $lastLocation=$_POST['location'];
// $petType=$_POST['petType'];
// $identityMark=$_POST['mark'];
// $color=$_POST['color'];
// $breed=$_POST['breed'];

// $name=$_POST['name'];
// $number=$_POST['number'];
// $address=$_POST['address'];
// $submit=$_POST['submit'];


// define('DB_SERVER','localhost');
// define('DB_USERNAME','root');
// define('DB_PASSWORD','');
// define('DB_NAME','login');
//connect database

// $conn=new mysqli('localhost','root','','test');
// $conn=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_NAME,3307);

// if($conn==false){
    // dir('connection failed');
    //die('Connection Failed : ' .$conn->connect_error);
// }
// else{
//     $stmt=$conn->prepare("insert into registeration(uploadPhoto,lastLocation,petType,identityMark,color,breed)
//     values(?,?,?,?,?,?)");
//     // ,number,address
//     // ,$number,$address
//     $stmt->blind_param("sssssi",$uploadPhoto,$lastLocation,$petType,$identityMark,$color,$breed);
//     $stmt->execute();
//     echo "report registered successfully...";
//     $stmt->close();
//     $conn->close();
// }

/*
This file contains database configuration assuming you are running mysql using user "root" and password ""
*/

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'login');

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
}


?>